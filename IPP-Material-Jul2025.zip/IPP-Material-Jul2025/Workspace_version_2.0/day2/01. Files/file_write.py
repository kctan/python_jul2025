
helloFile = open("hello2.txt", "a")
helloFile.write("I am teaching in RP today\nthis is 2nd line\nhow are you\n")
helloFile.close()

'''
# reopen to display content
helloFile = open("hello.txt")
print(helloFile.read())
helloFile.close()
 
# open the file for adding next text
helloFile = open("hello.txt", "a")
helloFile.write("Hello world again\n")
helloFile.close()

# reopen to display content
helloFile = open("hello.txt")
print(helloFile.read())
helloFile.close()
'''