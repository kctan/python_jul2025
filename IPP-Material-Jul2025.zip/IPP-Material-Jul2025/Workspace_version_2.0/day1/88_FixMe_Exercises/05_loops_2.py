#"Hello world" will be printed 5 times

for i in range(5, FIX_ME):
    FIX_ME
