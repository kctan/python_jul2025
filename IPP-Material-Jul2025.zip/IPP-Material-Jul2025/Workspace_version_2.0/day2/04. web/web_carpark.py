import json
import requests

url="https://api.data.gov.sg/v1/transport/carpark-availability"
req=requests.get(url)

data = json.loads(req.text)

# print update timestamp
update_time = data["items"][0]["timestamp"]
print("Time: " + update_time)

# print forecast
carpark = data["items"][0]["carpark_data"][0]["carpark_number"]
print("Car park number: " + carpark)


'''
helloFile = open("weather.txt", "a")
helloFile.write("Weather is " + forecast + "\n\n")
helloFile.close()

'''
