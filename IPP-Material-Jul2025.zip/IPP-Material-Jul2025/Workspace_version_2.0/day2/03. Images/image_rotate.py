import os
from PIL import Image, ImageFilter, ImageOps, ImageEnhance

filename = "img/clungup.jpg"

im = Image.open(filename)

# ROTATING
#out = im.transpose(Image.ROTATE_90)
#out = im.transpose(Image.ROTATE_180)
#out = im.transpose(Image.ROTATE_270)

# FLIPPING
#out = im.transpose(Image.FLIP_LEFT_RIGHT)
#out = im.transpose(Image.FLIP_TOP_BOTTOM)

enh = ImageEnhance.Contrast(im)
out = enh.enhance(1.3)

#im.show()
out.show()
