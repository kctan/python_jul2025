person = 23

if FIX_ME >= 21:
    print ("This person is an adult")
else:
    print ("This person is a minor")




vip = "Jack"

if vip FIX_ME "Jack":
    print ("Welcome, CEO")
FIX_ME vip == "Mary":
    print ("Welcome, CFO")
else FIX_ME
    print ("Unrecognised person")