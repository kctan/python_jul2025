data1 = input("Enter a number : ")

print ("Number received is : " + data1 )


#FIX_ME (the line below)
larger_data1 = data1 + 1

print ("One number larger than the number received is : " + FIX_ME )

